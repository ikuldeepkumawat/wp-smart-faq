<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function myplugin_settings_page() {
    // Save new template
    if ( isset($_POST['myplugin_create_template']) && !empty($_POST['template_name']) ) {
        $template_name = sanitize_text_field($_POST['template_name']);
        $template_slug = sanitize_title($template_name);

        $upload_dir = plugin_dir_path(__DIR__) . 'templates/';

        if ( ! file_exists($upload_dir) ) {
            wp_mkdir_p($upload_dir);
        }

        $file_path = $upload_dir . $template_slug . '.php';

        if ( ! file_exists($file_path) ) {
            $template_content = "<?php\n// Template: {$template_name}\n?>\n<h1>{$template_name}</h1>\n<p>This is {$template_name} template.</p>";
            file_put_contents($file_path, $template_content);
            echo '<div class="updated"><p>Template <b>' . esc_html($template_name) . '</b> created successfully!</p></div>';
        } else {
            echo '<div class="error"><p>Template already exists!</p></div>';
        }
    }
    ?>
    <div class="wrap">
        <h1>My Plugin - Templates</h1>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th><label for="template_name">Template Name</label></th>
                    <td>
                        <input type="text" name="template_name" id="template_name" required />
                    </td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="myplugin_create_template" class="button-primary" value="Create Template" />
            </p>
        </form>
        <h2>Available Templates</h2>
        <ul>
            <?php
            $template_dir = plugin_dir_path(__DIR__) . 'templates/';
            if ( file_exists($template_dir) ) {
                $files = glob($template_dir . '*.php');
                if ( $files ) {
                    foreach ($files as $file) {
                        echo '<li>' . basename($file) . '</li>';
                    }
                } else {
                    echo '<li>No templates found.</li>';
                }
            }
            ?>
        </ul>
    </div>
    <?php
}
