<?php
function dt_admin_page() {
    if (isset($_POST['dt_template_name'])) {
        $name = sanitize_text_field($_POST['dt_template_name']);
        $filename = 'template-' . sanitize_title($name) . '.php';
        $filepath = plugin_dir_path(__FILE__) . 'templates/' . $filename;

        if (!file_exists($filepath)) {
            $content = "<?php\n/*\nTemplate Name: $name\n*/\n?>\n<h1>$name Page Template</h1>";
            file_put_contents($filepath, $content);
            echo "<div class='updated'><p>Template <b>$name</b> created successfully!</p></div>";
        } else {
            echo "<div class='error'><p>Template already exists!</p></div>";
        }
    }

    ?>
    <div class="wrap">
        <h1>Create New Template</h1>
        <form method="post">
            <input type="text" name="dt_template_name" placeholder="Template Name" required>
            <button type="submit" class="button button-primary">Create Template</button>
        </form>
    </div>
    <?php
}
