<?php
// Admin menu add karna
add_action('admin_menu', 'wp_easystyler_menu');

function wp_easystyler_menu() {
    // Main Menu
    add_menu_page(
        'EasyStyler Settings',
        'EasyStyler',
        'manage_options',
        'wp-easystyler',
        'wp_easystyler_settings_page',
        'dashicons-admin-customizer',
        20
    );

    // Submenu: Settings
    add_submenu_page(
        'wp-easystyler',
        'EasyStyler Settings',
        'Settings',
        'manage_options',
        'wp-easystyler',
        'wp_easystyler_settings_page'
    );

    // Submenu: Template Generator
    add_submenu_page(
        'wp-easystyler',
        'Template Generator',
        'Template Generator',
        'manage_options',
        'wp-easystyler-template-generator',
        'wp_easystyler_template_generator_page'
    );
}

// Settings Page
function wp_easystyler_settings_page() {
    ?>
    <div class="wrap">
        <h1>WP EasyStyler Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('wp_easystyler_options_group');
            do_settings_sections('wp-easystyler');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Template Generator Page
function wp_easystyler_template_generator_page() {
    if (isset($_POST['template_name'])) {
        $name = sanitize_text_field($_POST['template_name']);
        $filename = 'template-' . sanitize_title($name) . '.php';
        $dir = plugin_dir_path(__FILE__) . 'templates/';
        if (!file_exists($dir)) {
            mkdir($dir, 0755, true);
        }
        $filepath = $dir . $filename;

        if (!file_exists($filepath)) {
            $content = "<?php\n/*\nTemplate Name: $name\n*/\n?>\n<h1>$name Page Template</h1>";
            file_put_contents($filepath, $content);
            echo '<div class="updated"><p>Template <b>' . esc_html($name) . '</b> created successfully!</p></div>';
        } else {
            echo '<div class="error"><p>Template already exists!</p></div>';
        }
    }
    ?>
    <div class="wrap">
        <h1>Template Generator</h1>
        <form method="post">
            <input type="text" name="template_name" placeholder="Enter Template Name" required>
            <button type="submit" class="button button-primary">Create Template</button>
        </form>
    </div>
    <?php
}

// Include Admin Settings
require_once plugin_dir_path(__FILE__) . '../admin/settings-page.php';
