<?php
// Frontend CSS enqueue
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style(
        'wp-easystyler-css',
        WP_ES_URL . 'assets/css/easystyler.css',
        [],
        '1.0'
    );
});
