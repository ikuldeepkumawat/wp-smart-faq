<?php
// Register custom page template
add_filter('theme_page_templates', function($templates) {
    $templates['wp-easystyler-template.php'] = 'EasyStyler Custom Page';
    return $templates;
});

// Load template from plugin folder
add_filter('template_include', function($template) {
    if (is_page()) {
        $chosen_template = get_page_template_slug(get_queried_object_id());
        if ($chosen_template === 'wp-easystyler-template.php') {
            return plugin_dir_path(__FILE__) . '../templates/custom-page.php';
        }
    }
    return $template;
});
