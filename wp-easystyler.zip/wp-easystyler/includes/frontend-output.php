<?php
add_action('wp_footer', 'wp_easystyler_output');

function wp_easystyler_output() {
    $text      = get_option('wp_easystyler_text', 'Hello from EasyStyler!');
    $color     = get_option('wp_easystyler_color', '#000000');
    $maxwidth  = get_option('wp_easystyler_maxwidth', '800');

    echo '<div class="easystyler-container" style="--es-color:' . esc_attr($color) . '; --es-maxwidth:' . esc_attr($maxwidth) . 'px;">';
    echo '<span class="easystyler-text">' . esc_html($text) . '</span>';
    echo '</div>';
}
