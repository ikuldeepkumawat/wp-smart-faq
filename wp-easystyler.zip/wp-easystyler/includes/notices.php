<?php
// Custom admin notice
add_action('admin_notices', 'wp_easystyler_admin_notice');

function wp_easystyler_admin_notice() {
    if (isset($_GET['settings-updated']) && $_GET['settings-updated']) {
        echo '<div class="notice notice-success is-dismissible">
                <p><strong>EasyStyler settings saved successfully! 🎉</strong></p>
              </div>';
    }
}
