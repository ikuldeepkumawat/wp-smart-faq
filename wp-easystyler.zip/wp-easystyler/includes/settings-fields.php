<?php
add_action('admin_init', 'wp_easystyler_register_settings');

function wp_easystyler_register_settings() {
    register_setting('wp_easystyler_options_group', 'wp_easystyler_text');
    register_setting('wp_easystyler_options_group', 'wp_easystyler_color');
    register_setting('wp_easystyler_options_group', 'wp_easystyler_maxwidth'); // NEW

    add_settings_section('wp_easystyler_section', 'Custom Styling', null, 'wp-easystyler');

    add_settings_field('wp_easystyler_text', 'Custom Text', 'wp_easystyler_text_callback', 'wp-easystyler', 'wp_easystyler_section');
    add_settings_field('wp_easystyler_color', 'Text Color', 'wp_easystyler_color_callback', 'wp-easystyler', 'wp_easystyler_section');
    add_settings_field('wp_easystyler_maxwidth', 'Container Max-Width', 'wp_easystyler_maxwidth_callback', 'wp-easystyler', 'wp_easystyler_section'); // NEW
}

function wp_easystyler_text_callback() {
    $value = get_option('wp_easystyler_text', '');
    echo '<input type="text" name="wp_easystyler_text" value="' . esc_attr($value) . '" style="width:300px;">';
}

function wp_easystyler_color_callback() {
    $value = get_option('wp_easystyler_color', '#000000');
    echo '<input type="color" name="wp_easystyler_color" value="' . esc_attr($value) . '">';
}

// NEW
function wp_easystyler_maxwidth_callback() {
    $value = get_option('wp_easystyler_maxwidth', '800');
    echo '<input type="number" name="wp_easystyler_maxwidth" value="' . esc_attr($value) . '" style="width:100px;"> px';
}
