<?php
/**
 * Template Name: EasyStyler Custom Page
 */
get_header(); 
    $text      = get_option('wp_easystyler_text', 'Hello from EasyStyler!');
    $color     = get_option('wp_easystyler_color', '#000000');
    $maxwidth  = get_option('wp_easystyler_maxwidth', '800');
?>

<div class="easystyler-page">
    <div class="easystyler-container" style="--es-color:<?php echo esc_attr($color); ?>; --es-maxwidth:<?php echo esc_attr($maxwidth); ?>px;">
        <span class="easystyler-text">Welcome to the EasyStyler Custom Page!</span>
        <h1><?php the_title(); ?></h1>
        <p>Ye ek custom page hai jo WP EasyStyler plugin ne add kiya hai.</p>
    </div>
</div>


<?php get_footer(); ?>
