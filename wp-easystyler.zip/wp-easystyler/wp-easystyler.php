<?php
/**
 * Plugin Name: WP EasyStyler
 * Description: Ek simple plugin jo custom section aur style options add karta hai.
 * Version: 1.0
 * Author: Kuldeep Kumawat
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'WP_ES_PATH', plugin_dir_path( __FILE__ ) );
define( 'WP_ES_URL',  plugin_dir_url( __FILE__ ) );

require_once WP_ES_PATH . 'includes/admin-menu.php';
require_once WP_ES_PATH . 'includes/settings-fields.php';
require_once WP_ES_PATH . 'includes/notices.php';
require_once WP_ES_PATH . 'includes/frontend-output.php';
require_once WP_ES_PATH . 'includes/assets.php'; // NEW
require_once WP_ES_PATH . 'includes/custom-template.php';


